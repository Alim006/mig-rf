import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { DocumentType, StepStatus } from '@prisma/client';

@Injectable()
export class DocumentsService {
  constructor(private prisma: PrismaService) {}

  async uploadDocument(userId: string, type: DocumentType, fileUrl: string) {
    // Mock OCR for document types that need it
    const ocrData = this.mockOcr(type, fileUrl);

    const document = await this.prisma.document.create({
      data: { userId, type, fileUrl, ocrData, status: StepStatus.UPLOADED },
    });

    // Update verification step
    await this.prisma.verificationStep.updateMany({
      where: { userId, stepName: type },
      data: { status: StepStatus.UPLOADED, documentId: document.id },
    });

    // Recalculate user status
    await this.recalculateStatus(userId);

    return document;
  }

  async getUserDocuments(userId: string) {
    return this.prisma.document.findMany({
      where: { userId },
      orderBy: { uploadedAt: 'desc' },
    });
  }

  private mockOcr(type: DocumentType, fileUrl: string): any {
    if (type === DocumentType.UNIVERSITY_LETTER) {
      return {
        universityName: 'МГУ им. М.В. Ломоносова',
        enrollmentDate: '2024-09-01',
        studyDuration: '4 years',
        studyForm: 'Full-time',
      };
    }
    return null;
  }

  private async recalculateStatus(userId: string) {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user) return;

    const steps = await this.prisma.verificationStep.findMany({ where: { userId } });
    const now = new Date();

    // Check stay expiry
    if (user.stayUntil) {
      const daysLeft = Math.ceil((user.stayUntil.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
      if (daysLeft < 0) {
        await this.prisma.user.update({ where: { id: userId }, data: { status: 'RED' } });
        return;
      }
      if (daysLeft <= 7) {
        await this.prisma.user.update({ where: { id: userId }, data: { status: 'YELLOW' } });
        return;
      }
    }

    // Check if any steps are overdue
    const overdueStep = steps.find(s =>
      s.dueDate && s.dueDate < now && s.status === 'PENDING'
    );
    if (overdueStep) {
      await this.prisma.user.update({ where: { id: userId }, data: { status: 'RED' } });
      return;
    }

    // Check if steps are approaching due date
    const warningStep = steps.find(s => {
      if (!s.dueDate || s.status !== 'PENDING') return false;
      const daysLeft = Math.ceil((s.dueDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
      return daysLeft <= 7;
    });
    if (warningStep) {
      await this.prisma.user.update({ where: { id: userId }, data: { status: 'YELLOW' } });
      return;
    }

    // Check if all steps complete
    const pendingSteps = steps.filter(s => s.status === 'PENDING');
    if (pendingSteps.length === 0 || steps.length === 0) {
      await this.prisma.user.update({ where: { id: userId }, data: { status: 'GREEN' } });
    }
  }
}
