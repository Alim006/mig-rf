import { Controller, Get, Patch, Post, Param, Body, Query, UseGuards, Request } from '@nestjs/common';
import { AdminService } from './admin.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@Controller('admin')
@UseGuards(JwtAuthGuard)
export class AdminController {
  constructor(private adminService: AdminService) {}

  @Get('stats')
  getStats() {
    return this.adminService.getStats();
  }

  @Get('users')
  getUsers(@Query('page') page: string, @Query('status') status: string) {
    return this.adminService.getUsers(parseInt(page) || 1, 20, status);
  }

  @Get('users/:id')
  getUserDetail(@Param('id') id: string) {
    return this.adminService.getUserDetail(id);
  }

  @Patch('users/:id/status')
  updateStatus(@Param('id') id: string, @Body('status') status: string, @Request() req) {
    return this.adminService.updateUserStatus(id, status, req.user.id);
  }

  @Post('users/:id/block')
  blockUser(@Param('id') id: string, @Request() req) {
    return this.adminService.blockUser(id, req.user.id);
  }

  @Get('logs')
  getLogs(@Query('page') page: string) {
    return this.adminService.getAuditLogs(parseInt(page) || 1);
  }
}
