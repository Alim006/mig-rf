# mig.rf — Приложение для мигрантов в России

Мобильное приложение для легального пребывания мигрантов в России с отслеживанием статуса, загрузкой документов и QR-кодом для проверки.

---

## 🏗️ Архитектура

```
mig-rf/
├── backend/          # NestJS API + PostgreSQL
│   ├── src/
│   │   ├── auth/     # JWT, SMS, PIN авторизация
│   │   ├── users/    # Профиль, workflow
│   │   ├── documents/ # Загрузка документов
│   │   ├── qr/       # QR-коды
│   │   └── admin/    # Административная панель
│   └── prisma/       # Схема БД + seed
├── frontend/         # Flutter (iOS + Android)
│   └── lib/
│       ├── bloc/     # State management
│       ├── screens/  # UI экраны
│       ├── services/ # API и хранилище
│       └── theme/    # Стили и цвета
└── docker-compose.yml
```

---

## 🚀 Быстрый запуск (Docker)

### 1. Клонируйте и настройте

```bash
git clone <repo>
cd mig-rf
cp .env.example .env
# Отредактируйте .env под ваши нужды
```

### 2. Запустите через Docker Compose

```bash
docker-compose up --build
```

**Сервисы:**
- Backend API: http://localhost:3000
- Admin Web: http://localhost:8080
- PostgreSQL: localhost:5432

---

## 🔧 Запуск без Docker

### Backend

```bash
cd backend
npm install
cp ../.env.example .env

# Настройте DATABASE_URL в .env
npx prisma migrate dev --name init
npx prisma generate
npx ts-node prisma/seed.ts   # Создает admin + mock данные

npm run start:dev
```

### Frontend (Flutter)

```bash
cd frontend
flutter pub get
flutter run
```

Для изменения URL API отредактируйте `lib/services/api_service.dart`:
```dart
static const String baseUrl = 'http://YOUR_IP:3000/api/v1';
```

---

## 👤 Тестовые аккаунты

| Тип | Логин | Пароль |
|-----|-------|--------|
| Admin | admin | admin |
| Мигрант | +79001234567 | test123 |

---

## 📱 Экраны приложения

1. **Выбор языка** — Русский, English, O'zbek, Тоҷикӣ, Кыргызча
2. **Вход / Регистрация** — SMS или пароль
3. **PIN-код** — 4-значный PIN для быстрого входа
4. **Личный кабинет** — Профиль, статус, документы
5. **Цель визита** — Туризм / Учёба / Работа / Деловой / Диплом.
6. **Workflow** — Пошаговое выполнение требований
7. **QR-код** — Динамический, обновляется каждые 60 сек
8. **Админ-панель** — Управление пользователями, проверка QR

---

## 🛡️ Безопасность

- **Пароли** — bcrypt (salt rounds: 12)
- **Персональные данные** — AES-256-CBC шифрование в БД
- **JWT** — Access token 15 мин, Refresh token 7 дней
- **Rate limiting** — Throttler (30 req/min по умолчанию)
- **SMS** — Max 3 запроса/мин, max 5 попыток ввода
- **Валидация** — class-validator на всех входных данных
- **Helmet** — HTTP security headers

---

## 📊 Система статусов

| Статус | Цвет | Значение |
|--------|------|----------|
| GREEN | 🟢 | Всё в порядке |
| YELLOW | 🟡 | До истечения < 7 дней |
| RED | 🔴 | Нарушение / срок истёк |
| PENDING | ⚪ | Данные не заполнены |

---

## 🔌 API Endpoints

### Auth
```
POST /api/v1/auth/sms/send          - Отправить SMS
POST /api/v1/auth/register/sms      - Регистрация по SMS
POST /api/v1/auth/register/password - Регистрация паролем
POST /api/v1/auth/login/sms         - Вход по SMS
POST /api/v1/auth/login/password    - Вход паролем
POST /api/v1/auth/login/pin         - Вход по PIN
POST /api/v1/auth/pin/set           - Установить PIN
POST /api/v1/auth/refresh           - Обновить токен
POST /api/v1/auth/logout            - Выход
POST /api/v1/auth/admin/login       - Вход администратора
```

### Users (требует JWT)
```
GET  /api/v1/users/me               - Получить профиль
PUT  /api/v1/users/me               - Обновить профиль
POST /api/v1/users/me/visit-type    - Установить цель визита
GET  /api/v1/users/me/steps         - Шаги workflow
```

### Documents (требует JWT)
```
POST /api/v1/documents/upload       - Загрузить документ
GET  /api/v1/documents              - Мои документы
```

### QR
```
GET  /api/v1/qr/generate            - Сгенерировать QR (JWT)
GET  /api/v1/qr/verify?token=...    - Проверить QR
```

### Admin (требует JWT admin)
```
GET    /api/v1/admin/stats          - Статистика
GET    /api/v1/admin/users          - Список пользователей
GET    /api/v1/admin/users/:id      - Детали пользователя
PATCH  /api/v1/admin/users/:id/status - Изменить статус
POST   /api/v1/admin/users/:id/block  - Заблокировать
GET    /api/v1/admin/logs           - Логи действий
```

---

## 🧪 Тесты

```bash
cd backend
npm test
npm run test:cov
```

---

## 📝 Переменные окружения

| Переменная | Описание |
|-----------|----------|
| DATABASE_URL | PostgreSQL URL |
| JWT_SECRET | Секрет для JWT (мин. 32 символа) |
| JWT_REFRESH_SECRET | Секрет для refresh token |
| ENCRYPTION_KEY | Ключ шифрования данных (32 символа) |
| PORT | Порт сервера (default: 3000) |

---

## 🔄 SMS-провайдеры для продакшна

Замените mock в `backend/src/auth/sms.service.ts`:
- **SMSC.ru** — https://smsc.ru/api/
- **SMS.ru** — https://sms.ru/api/
- **МТС Exolve** — https://exolve.ru/

---

## 📦 Сборка Flutter APK

```bash
cd frontend
flutter build apk --release
# APK: build/app/outputs/flutter-apk/app-release.apk
```

iOS:
```bash
flutter build ios --release
```
