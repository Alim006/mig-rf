import { Controller, Get, Put, Body, UseGuards, Request, Post, Param } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { UsersService } from './users.service';
import { UpdateProfileDto, SetVisitTypeDto } from './dto/user.dto';

@Controller('users')
@UseGuards(JwtAuthGuard)
export class UsersController {
  constructor(private usersService: UsersService) {}

  @Get('me')
  getProfile(@Request() req) {
    return this.usersService.getProfile(req.user.id);
  }

  @Put('me')
  updateProfile(@Request() req, @Body() dto: UpdateProfileDto) {
    return this.usersService.updateProfile(req.user.id, dto);
  }

  @Post('me/visit-type')
  setVisitType(@Request() req, @Body() dto: SetVisitTypeDto) {
    return this.usersService.setVisitType(req.user.id, dto.visitType);
  }

  @Get('me/steps')
  getWorkflowSteps(@Request() req) {
    return this.usersService.getWorkflowSteps(req.user.id);
  }
}
