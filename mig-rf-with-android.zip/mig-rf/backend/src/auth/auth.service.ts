import {
  Injectable,
  UnauthorizedException,
  BadRequestException,
  ConflictException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';
import { PrismaService } from '../prisma/prisma.service';
import { SmsService } from './sms.service';

@Injectable()
export class AuthService {
  constructor(
    private prisma: PrismaService,
    private jwtService: JwtService,
    private smsService: SmsService,
  ) {}

  // Send SMS code (mock)
  async sendSmsCode(phone: string) {
    const code = this.smsService.generateCode();
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000); // 5 min

    // Delete old codes
    await this.prisma.smsCode.deleteMany({ where: { phone } });

    await this.prisma.smsCode.create({
      data: { phone, code, expiresAt },
    });

    // In production: send real SMS. Mock: return code in dev
    if (process.env.NODE_ENV !== 'production') {
      console.log(`📱 SMS Code for ${phone}: ${code}`);
      return { message: 'Code sent', devCode: code };
    }
    return { message: 'Code sent' };
  }

  // Register with SMS
  async registerWithSms(phone: string, code: string) {
    await this.verifySmsCode(phone, code);

    const existing = await this.prisma.user.findUnique({ where: { phone } });
    if (existing) throw new ConflictException('User already exists');

    const user = await this.prisma.user.create({ data: { phone } });
    return this.generateTokens(user.id, user.phone);
  }

  // Register with password
  async registerWithPassword(phone: string, password: string) {
    const existing = await this.prisma.user.findUnique({ where: { phone } });
    if (existing) throw new ConflictException('User already exists');

    const passwordHash = await bcrypt.hash(password, 12);
    const user = await this.prisma.user.create({ data: { phone, passwordHash } });
    return this.generateTokens(user.id, user.phone);
  }

  // Login with SMS
  async loginWithSms(phone: string, code: string) {
    await this.verifySmsCode(phone, code);
    const user = await this.prisma.user.findUnique({ where: { phone } });
    if (!user) throw new UnauthorizedException('User not found');
    if (user.isBlocked) throw new UnauthorizedException('Account blocked');
    return this.generateTokens(user.id, user.phone);
  }

  // Login with password
  async loginWithPassword(phone: string, password: string) {
    const user = await this.prisma.user.findUnique({ where: { phone } });
    if (!user || !user.passwordHash) throw new UnauthorizedException('Invalid credentials');
    if (user.isBlocked) throw new UnauthorizedException('Account blocked');

    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) throw new UnauthorizedException('Invalid credentials');

    return this.generateTokens(user.id, user.phone);
  }

  // Login with PIN
  async loginWithPin(userId: string, pin: string) {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user || !user.pinHash) throw new UnauthorizedException('PIN not set');
    if (user.isBlocked) throw new UnauthorizedException('Account blocked');

    const valid = await bcrypt.compare(pin, user.pinHash);
    if (!valid) throw new UnauthorizedException('Invalid PIN');

    return this.generateTokens(user.id, user.phone);
  }

  // Set PIN
  async setPin(userId: string, pin: string) {
    if (!/^\d{4}$/.test(pin)) throw new BadRequestException('PIN must be 4 digits');
    const pinHash = await bcrypt.hash(pin, 12);
    await this.prisma.user.update({ where: { id: userId }, data: { pinHash } });
    return { message: 'PIN set successfully' };
  }

  // Refresh tokens
  async refreshTokens(userId: string, refreshToken: string) {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user || !user.refreshToken) throw new UnauthorizedException();

    const valid = await bcrypt.compare(refreshToken, user.refreshToken);
    if (!valid) throw new UnauthorizedException('Invalid refresh token');

    return this.generateTokens(user.id, user.phone);
  }

  // Logout
  async logout(userId: string) {
    await this.prisma.user.update({
      where: { id: userId },
      data: { refreshToken: null },
    });
    return { message: 'Logged out' };
  }

  // Admin login
  async adminLogin(login: string, password: string) {
    const admin = await this.prisma.admin.findUnique({ where: { login } });
    if (!admin) throw new UnauthorizedException('Invalid credentials');

    const valid = await bcrypt.compare(password, admin.passwordHash);
    if (!valid) throw new UnauthorizedException('Invalid credentials');

    const payload = { sub: admin.id, login: admin.login, isAdmin: true };
    const accessToken = this.jwtService.sign(payload, {
      secret: process.env.JWT_SECRET,
      expiresIn: '8h',
    });

    return { accessToken, admin: { id: admin.id, login: admin.login, name: admin.name } };
  }

  private async verifySmsCode(phone: string, code: string) {
    const record = await this.prisma.smsCode.findFirst({
      where: { phone, used: false },
      orderBy: { createdAt: 'desc' },
    });

    if (!record || record.code !== code) {
      if (record) {
        await this.prisma.smsCode.update({
          where: { id: record.id },
          data: { attempts: { increment: 1 } },
        });
        if (record.attempts >= 4) throw new BadRequestException('Too many attempts');
      }
      throw new BadRequestException('Invalid code');
    }

    if (record.expiresAt < new Date()) throw new BadRequestException('Code expired');

    await this.prisma.smsCode.update({ where: { id: record.id }, data: { used: true } });
  }

  private async generateTokens(userId: string, phone: string) {
    const payload = { sub: userId, phone };

    const [accessToken, refreshToken] = await Promise.all([
      this.jwtService.signAsync(payload, {
        secret: process.env.JWT_SECRET,
        expiresIn: process.env.JWT_EXPIRES_IN || '15m',
      }),
      this.jwtService.signAsync(payload, {
        secret: process.env.JWT_REFRESH_SECRET,
        expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d',
      }),
    ]);

    const refreshHash = await bcrypt.hash(refreshToken, 10);
    await this.prisma.user.update({
      where: { id: userId },
      data: { refreshToken: refreshHash },
    });

    return { accessToken, refreshToken };
  }
}
