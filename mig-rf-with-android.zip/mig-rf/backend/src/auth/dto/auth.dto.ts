import { IsString, IsPhoneNumber, Length, Matches, MinLength } from 'class-validator';

export class SendSmsDto {
  @IsString()
  phone: string;
}

export class RegisterSmsDto {
  @IsString()
  phone: string;

  @IsString()
  @Length(4, 6)
  code: string;
}

export class RegisterPasswordDto {
  @IsString()
  phone: string;

  @IsString()
  @MinLength(6)
  password: string;
}

export class LoginSmsDto {
  @IsString()
  phone: string;

  @IsString()
  @Length(4, 6)
  code: string;
}

export class LoginPasswordDto {
  @IsString()
  phone: string;

  @IsString()
  password: string;
}

export class LoginPinDto {
  @IsString()
  userId: string;

  @IsString()
  @Matches(/^\d{4}$/)
  pin: string;
}

export class SetPinDto {
  @IsString()
  @Matches(/^\d{4}$/, { message: 'PIN must be 4 digits' })
  pin: string;

  @IsString()
  @Matches(/^\d{4}$/, { message: 'PIN confirmation must be 4 digits' })
  pinConfirm: string;
}

export class AdminLoginDto {
  @IsString()
  login: string;

  @IsString()
  password: string;
}
