import {
  Controller, Post, Body, UseGuards, Request, Get, Patch
} from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import { AuthService } from './auth.service';
import { JwtAuthGuard } from './guards/jwt-auth.guard';
import { JwtRefreshGuard } from './guards/jwt-refresh.guard';
import {
  SendSmsDto, RegisterSmsDto, RegisterPasswordDto,
  LoginSmsDto, LoginPasswordDto, LoginPinDto, SetPinDto, AdminLoginDto
} from './dto/auth.dto';

@Controller('auth')
export class AuthController {
  constructor(private authService: AuthService) {}

  @Post('sms/send')
  @Throttle({ default: { ttl: 60000, limit: 3 } })
  sendSms(@Body() dto: SendSmsDto) {
    return this.authService.sendSmsCode(dto.phone);
  }

  @Post('register/sms')
  registerSms(@Body() dto: RegisterSmsDto) {
    return this.authService.registerWithSms(dto.phone, dto.code);
  }

  @Post('register/password')
  registerPassword(@Body() dto: RegisterPasswordDto) {
    return this.authService.registerWithPassword(dto.phone, dto.password);
  }

  @Post('login/sms')
  loginSms(@Body() dto: LoginSmsDto) {
    return this.authService.loginWithSms(dto.phone, dto.code);
  }

  @Post('login/password')
  @Throttle({ default: { ttl: 60000, limit: 5 } })
  loginPassword(@Body() dto: LoginPasswordDto) {
    return this.authService.loginWithPassword(dto.phone, dto.password);
  }

  @Post('login/pin')
  @Throttle({ default: { ttl: 60000, limit: 5 } })
  loginPin(@Body() dto: LoginPinDto) {
    return this.authService.loginWithPin(dto.userId, dto.pin);
  }

  @Post('pin/set')
  @UseGuards(JwtAuthGuard)
  setPin(@Request() req, @Body() dto: SetPinDto) {
    return this.authService.setPin(req.user.id, dto.pin);
  }

  @Post('refresh')
  @UseGuards(JwtRefreshGuard)
  refresh(@Request() req) {
    return this.authService.refreshTokens(req.user.id, req.user.refreshToken);
  }

  @Post('logout')
  @UseGuards(JwtAuthGuard)
  logout(@Request() req) {
    return this.authService.logout(req.user.id);
  }

  @Post('admin/login')
  adminLogin(@Body() dto: AdminLoginDto) {
    return this.authService.adminLogin(dto.login, dto.password);
  }
}
