import { Injectable } from '@nestjs/common';

@Injectable()
export class SmsService {
  generateCode(): string {
    return Math.floor(1000 + Math.random() * 9000).toString();
  }

  // Mock: In production, integrate with real SMS provider (e.g., SMSC.ru, SMS.ru)
  async sendSms(phone: string, code: string): Promise<boolean> {
    console.log(`[MOCK SMS] To: ${phone} | Code: ${code}`);
    return true;
  }
}
