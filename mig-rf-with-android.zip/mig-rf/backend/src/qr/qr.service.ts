import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { PrismaService } from '../prisma/prisma.service';
import { EncryptionService } from '../common/encryption.service';
import * as QRCode from 'qrcode';

@Injectable()
export class QrService {
  constructor(
    private prisma: PrismaService,
    private jwtService: JwtService,
    private encryption: EncryptionService,
  ) {}

  async generateQr(userId: string): Promise<{ qrDataUrl: string; expiresAt: Date; token: string }> {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user) throw new Error('User not found');

    // Delete old tokens
    await this.prisma.qrToken.deleteMany({
      where: { userId, expiresAt: { lt: new Date() } },
    });

    const expiresAt = new Date(Date.now() + 60 * 1000); // 60 seconds

    const payload = {
      sub: userId,
      status: user.status,
      stayUntil: user.stayUntil,
      type: 'qr',
      exp: Math.floor(expiresAt.getTime() / 1000),
    };

    const token = this.jwtService.sign(payload, {
      secret: process.env.JWT_SECRET,
      expiresIn: '60s',
    });

    await this.prisma.qrToken.create({ data: { userId, token, expiresAt } });

    // Generate QR code with verification URL
    const verifyUrl = `${process.env.APP_URL || 'http://localhost:8080'}/admin/verify?token=${token}`;
    const qrDataUrl = await QRCode.toDataURL(verifyUrl, { width: 300 });

    return { qrDataUrl, expiresAt, token };
  }

  async verifyQr(token: string) {
    try {
      const payload = this.jwtService.verify(token, {
        secret: process.env.JWT_SECRET,
      });

      const user = await this.prisma.user.findUnique({
        where: { id: payload.sub },
      });

      if (!user) return { valid: false, error: 'User not found' };

      // Mark as scanned
      await this.prisma.qrToken.updateMany({
        where: { token },
        data: { scannedAt: new Date() },
      });

      return {
        valid: true,
        user: {
          id: user.id,
          fullName: user.fullNameEncrypted ? this.encryption.decrypt(user.fullNameEncrypted) : 'N/A',
          citizenship: user.citizenshipEncrypted ? this.encryption.decrypt(user.citizenshipEncrypted) : 'N/A',
          status: user.status,
          visitType: user.visitType,
          stayUntil: user.stayUntil,
          photoUrl: user.photoUrl,
          hasViolations: user.status === 'RED',
        },
      };
    } catch (e) {
      return { valid: false, error: 'Invalid or expired QR code' };
    }
  }
}
