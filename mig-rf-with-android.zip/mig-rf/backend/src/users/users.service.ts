import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { EncryptionService } from '../common/encryption.service';
import { UpdateProfileDto } from './dto/user.dto';

@Injectable()
export class UsersService {
  constructor(
    private prisma: PrismaService,
    private encryption: EncryptionService,
  ) {}

  async getProfile(userId: string) {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user) throw new NotFoundException('User not found');

    return {
      id: user.id,
      phone: user.phone,
      status: user.status,
      visitType: user.visitType,
      entryDate: user.entryDate,
      stayUntil: user.stayUntil,
      isVerified: user.isVerified,
      photoUrl: user.photoUrl,
      fullName: user.fullNameEncrypted ? this.encryption.decrypt(user.fullNameEncrypted) : null,
      birthdate: user.birthdateEncrypted ? this.encryption.decrypt(user.birthdateEncrypted) : null,
      citizenship: user.citizenshipEncrypted ? this.encryption.decrypt(user.citizenshipEncrypted) : null,
      passportNumber: user.passportEncrypted ? this.encryption.decrypt(user.passportEncrypted) : null,
      migrationCard: user.migrationCardEncrypted ? this.encryption.decrypt(user.migrationCardEncrypted) : null,
      address: user.addressEncrypted ? this.encryption.decrypt(user.addressEncrypted) : null,
    };
  }

  async updateProfile(userId: string, dto: UpdateProfileDto) {
    const updateData: any = {};

    if (dto.fullName) updateData.fullNameEncrypted = this.encryption.encrypt(dto.fullName);
    if (dto.birthdate) updateData.birthdateEncrypted = this.encryption.encrypt(dto.birthdate);
    if (dto.citizenship) updateData.citizenshipEncrypted = this.encryption.encrypt(dto.citizenship);
    if (dto.passportNumber) updateData.passportEncrypted = this.encryption.encrypt(dto.passportNumber);
    if (dto.migrationCard) updateData.migrationCardEncrypted = this.encryption.encrypt(dto.migrationCard);
    if (dto.address) updateData.addressEncrypted = this.encryption.encrypt(dto.address);
    if (dto.entryDate) updateData.entryDate = new Date(dto.entryDate);
    if (dto.visitType) {
      updateData.visitType = dto.visitType;
      updateData.stayUntil = this.calculateStayUntil(dto.visitType, dto.entryDate || new Date().toISOString());
    }

    updateData.isVerified = true;

    const user = await this.prisma.user.update({
      where: { id: userId },
      data: updateData,
    });

    if (dto.visitType) {
      await this.initializeWorkflowSteps(userId, dto.visitType);
    }

    return this.getProfile(userId);
  }

  async setVisitType(userId: string, visitType: string) {
    const stayUntil = this.calculateStayUntil(visitType, new Date().toISOString());
    await this.prisma.user.update({
      where: { id: userId },
      data: { visitType: visitType as any, stayUntil },
    });
    await this.initializeWorkflowSteps(userId, visitType);
    return { message: 'Visit type set' };
  }

  async getWorkflowSteps(userId: string) {
    return this.prisma.verificationStep.findMany({
      where: { userId },
      orderBy: { createdAt: 'asc' },
    });
  }

  private calculateStayUntil(visitType: string, entryDateStr: string): Date {
    const entryDate = new Date(entryDateStr);
    const days = {
      TOURISM: 90,
      STUDY: 365,
      WORK: 365,
      BUSINESS: 90,
      DIPLOMATIC: 365,
    }[visitType] || 90;

    return new Date(entryDate.getTime() + days * 24 * 60 * 60 * 1000);
  }

  private async initializeWorkflowSteps(userId: string, visitType: string) {
    const dueDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
    
    const steps: { stepName: string; dueDate?: Date }[] = [];

    if (visitType === 'STUDY') {
      steps.push(
        { stepName: 'UNIVERSITY_LETTER', dueDate },
        { stepName: 'MEDICAL_CERTIFICATE', dueDate },
        { stepName: 'DACTYLOSCOPY', dueDate },
        { stepName: 'REGISTRATION', dueDate },
      );
    } else if (visitType === 'WORK') {
      steps.push(
        { stepName: 'WORK_CONTRACT', dueDate },
        { stepName: 'MEDICAL_CERTIFICATE', dueDate },
        { stepName: 'DACTYLOSCOPY', dueDate },
        { stepName: 'REGISTRATION', dueDate },
      );
    } else if (visitType === 'BUSINESS') {
      steps.push({ stepName: 'BUSINESS_INVITATION' });
    } else if (visitType === 'DIPLOMATIC') {
      steps.push({ stepName: 'DIPLOMATIC_DOCUMENT' });
    }

    // Delete old steps and recreate
    await this.prisma.verificationStep.deleteMany({ where: { userId } });

    for (const step of steps) {
      await this.prisma.verificationStep.create({
        data: { userId, ...step },
      });
    }
  }
}
