import { Controller, Get, Post, Body, UseGuards, Request, Query } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { QrService } from './qr.service';

@Controller('qr')
export class QrController {
  constructor(private qrService: QrService) {}

  @Get('generate')
  @UseGuards(JwtAuthGuard)
  generate(@Request() req) {
    return this.qrService.generateQr(req.user.id);
  }

  @Get('verify')
  verify(@Query('token') token: string) {
    return this.qrService.verifyQr(token);
  }
}
