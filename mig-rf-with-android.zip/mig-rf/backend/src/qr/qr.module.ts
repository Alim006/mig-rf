import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { QrController } from './qr.controller';
import { QrService } from './qr.service';
import { EncryptionService } from '../common/encryption.service';

@Module({
  imports: [JwtModule.register({})],
  controllers: [QrController],
  providers: [QrService, EncryptionService],
})
export class QrModule {}
