import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  // Create admin
  const adminPassword = await bcrypt.hash('admin', 12);
  await prisma.admin.upsert({
    where: { login: 'admin' },
    update: {},
    create: {
      login: 'admin',
      passwordHash: adminPassword,
      name: 'Administrator',
      isSuper: true,
    },
  });

  // Create mock users
  const mockPhone = '+79001234567';
  const mockPassword = await bcrypt.hash('test123', 12);

  const crypto = require('crypto');
  const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY || '12345678901234567890123456789012';

  function encrypt(text: string): string {
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(ENCRYPTION_KEY), iv);
    let encrypted = cipher.update(text);
    encrypted = Buffer.concat([encrypted, cipher.final()]);
    return iv.toString('hex') + ':' + encrypted.toString('hex');
  }

  await prisma.user.upsert({
    where: { phone: mockPhone },
    update: {},
    create: {
      phone: mockPhone,
      passwordHash: mockPassword,
      fullNameEncrypted: encrypt('Иванов Иван Иванович'),
      birthdateEncrypted: encrypt('1990-05-15'),
      citizenshipEncrypted: encrypt('Узбекистан'),
      passportEncrypted: encrypt('AB1234567'),
      migrationCardEncrypted: encrypt('MK-2024-001'),
      addressEncrypted: encrypt('Москва, ул. Тверская, д.1'),
      visitType: 'WORK',
      status: 'GREEN',
      entryDate: new Date('2024-01-01'),
      stayUntil: new Date('2025-01-01'),
      isVerified: true,
    },
  });

  console.log('✅ Seed completed');
  console.log('Admin: login=admin, password=admin');
  console.log('Mock user: phone=+79001234567, password=test123');
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
