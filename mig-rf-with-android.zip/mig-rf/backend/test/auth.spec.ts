import { Test } from '@nestjs/testing';
import { AuthService } from '../src/auth/auth.service';
import { SmsService } from '../src/auth/sms.service';
import { JwtService } from '@nestjs/jwt';
import { PrismaService } from '../src/prisma/prisma.service';
import * as bcrypt from 'bcrypt';

// Mock PrismaService
const mockPrisma = {
  user: {
    findUnique: jest.fn(),
    create: jest.fn(),
    update: jest.fn(),
  },
  smsCode: {
    deleteMany: jest.fn(),
    create: jest.fn(),
    findFirst: jest.fn(),
    update: jest.fn(),
  },
  admin: {
    findUnique: jest.fn(),
  },
};

describe('AuthService', () => {
  let authService: AuthService;

  beforeEach(async () => {
    const moduleRef = await Test.createTestingModule({
      providers: [
        AuthService,
        SmsService,
        { provide: PrismaService, useValue: mockPrisma },
        {
          provide: JwtService,
          useValue: {
            signAsync: jest.fn().mockResolvedValue('mock_token'),
            sign: jest.fn().mockReturnValue('mock_token'),
            verify: jest.fn().mockReturnValue({ sub: 'user-id' }),
          },
        },
      ],
    }).compile();

    authService = moduleRef.get<AuthService>(AuthService);
    jest.clearAllMocks();
  });

  describe('sendSmsCode', () => {
    it('should create SMS code', async () => {
      mockPrisma.smsCode.deleteMany.mockResolvedValue({});
      mockPrisma.smsCode.create.mockResolvedValue({ id: '1', code: '1234' });

      const result = await authService.sendSmsCode('+79001234567');
      expect(result.message).toBe('Code sent');
      expect(mockPrisma.smsCode.create).toHaveBeenCalled();
    });
  });

  describe('registerWithPassword', () => {
    it('should create user with hashed password', async () => {
      mockPrisma.user.findUnique.mockResolvedValue(null);
      mockPrisma.user.create.mockResolvedValue({ id: 'user-1', phone: '+79001234567' });
      mockPrisma.user.update.mockResolvedValue({});

      const result = await authService.registerWithPassword('+79001234567', 'password123');
      expect(result.accessToken).toBeDefined();
      expect(mockPrisma.user.create).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({ phone: '+79001234567' }),
        }),
      );
    });

    it('should throw if user already exists', async () => {
      mockPrisma.user.findUnique.mockResolvedValue({ id: 'existing' });
      await expect(authService.registerWithPassword('+79001234567', 'pass')).rejects.toThrow();
    });
  });

  describe('loginWithPassword', () => {
    it('should login with correct credentials', async () => {
      const hash = await bcrypt.hash('password123', 12);
      mockPrisma.user.findUnique.mockResolvedValue({
        id: 'user-1',
        phone: '+79001234567',
        passwordHash: hash,
        isBlocked: false,
      });
      mockPrisma.user.update.mockResolvedValue({});

      const result = await authService.loginWithPassword('+79001234567', 'password123');
      expect(result.accessToken).toBeDefined();
    });

    it('should throw with wrong password', async () => {
      const hash = await bcrypt.hash('correct', 12);
      mockPrisma.user.findUnique.mockResolvedValue({
        id: 'user-1',
        passwordHash: hash,
        isBlocked: false,
      });

      await expect(authService.loginWithPassword('+7900', 'wrong')).rejects.toThrow();
    });
  });

  describe('setPin', () => {
    it('should reject non-4-digit PIN', async () => {
      await expect(authService.setPin('user-1', '123')).rejects.toThrow('PIN must be 4 digits');
      await expect(authService.setPin('user-1', '12345')).rejects.toThrow('PIN must be 4 digits');
      await expect(authService.setPin('user-1', 'abcd')).rejects.toThrow('PIN must be 4 digits');
    });

    it('should set PIN', async () => {
      mockPrisma.user.update.mockResolvedValue({});
      const result = await authService.setPin('user-1', '1234');
      expect(result.message).toBe('PIN set successfully');
    });
  });
});

describe('SmsService', () => {
  let smsService: SmsService;

  beforeEach(() => {
    smsService = new SmsService();
  });

  it('should generate 4-digit code', () => {
    const code = smsService.generateCode();
    expect(code).toMatch(/^\d{4}$/);
    expect(parseInt(code)).toBeGreaterThanOrEqual(1000);
    expect(parseInt(code)).toBeLessThanOrEqual(9999);
  });
});
