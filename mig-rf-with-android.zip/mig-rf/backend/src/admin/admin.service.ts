import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { EncryptionService } from '../common/encryption.service';

@Injectable()
export class AdminService {
  constructor(
    private prisma: PrismaService,
    private encryption: EncryptionService,
  ) {}

  async getUsers(page = 1, limit = 20, status?: string) {
    const where = status ? { status: status as any } : {};
    const [users, total] = await Promise.all([
      this.prisma.user.findMany({
        where,
        skip: (page - 1) * limit,
        take: limit,
        orderBy: { createdAt: 'desc' },
        select: {
          id: true, phone: true, status: true, visitType: true,
          isVerified: true, isBlocked: true, stayUntil: true,
          fullNameEncrypted: true, citizenshipEncrypted: true,
          createdAt: true,
        },
      }),
      this.prisma.user.count({ where }),
    ]);

    const decryptedUsers = users.map(u => ({
      ...u,
      fullName: u.fullNameEncrypted ? this.encryption.decrypt(u.fullNameEncrypted) : null,
      citizenship: u.citizenshipEncrypted ? this.encryption.decrypt(u.citizenshipEncrypted) : null,
      fullNameEncrypted: undefined,
      citizenshipEncrypted: undefined,
    }));

    return { users: decryptedUsers, total, page, pages: Math.ceil(total / limit) };
  }

  async getUserDetail(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      include: {
        documents: true,
        verificationSteps: true,
      },
    });
    if (!user) return null;

    return {
      ...user,
      fullName: user.fullNameEncrypted ? this.encryption.decrypt(user.fullNameEncrypted) : null,
      birthdate: user.birthdateEncrypted ? this.encryption.decrypt(user.birthdateEncrypted) : null,
      citizenship: user.citizenshipEncrypted ? this.encryption.decrypt(user.citizenshipEncrypted) : null,
      passportNumber: user.passportEncrypted ? this.encryption.decrypt(user.passportEncrypted) : null,
      migrationCard: user.migrationCardEncrypted ? this.encryption.decrypt(user.migrationCardEncrypted) : null,
      address: user.addressEncrypted ? this.encryption.decrypt(user.addressEncrypted) : null,
      fullNameEncrypted: undefined,
      birthdateEncrypted: undefined,
      citizenshipEncrypted: undefined,
      passportEncrypted: undefined,
      migrationCardEncrypted: undefined,
      addressEncrypted: undefined,
    };
  }

  async updateUserStatus(userId: string, status: string, adminId: string) {
    await this.prisma.user.update({
      where: { id: userId },
      data: { status: status as any },
    });

    await this.prisma.auditLog.create({
      data: {
        userId,
        adminId,
        action: 'STATUS_CHANGE',
        details: { newStatus: status },
      },
    });

    return { message: 'Status updated' };
  }

  async blockUser(userId: string, adminId: string) {
    await this.prisma.user.update({ where: { id: userId }, data: { isBlocked: true } });
    await this.prisma.auditLog.create({
      data: { userId, adminId, action: 'USER_BLOCKED' },
    });
    return { message: 'User blocked' };
  }

  async getAuditLogs(page = 1) {
    const [logs, total] = await Promise.all([
      this.prisma.auditLog.findMany({
        skip: (page - 1) * 50,
        take: 50,
        orderBy: { createdAt: 'desc' },
        include: { admin: { select: { login: true, name: true } } },
      }),
      this.prisma.auditLog.count(),
    ]);
    return { logs, total };
  }

  async getStats() {
    const [total, green, yellow, red, pending] = await Promise.all([
      this.prisma.user.count(),
      this.prisma.user.count({ where: { status: 'GREEN' } }),
      this.prisma.user.count({ where: { status: 'YELLOW' } }),
      this.prisma.user.count({ where: { status: 'RED' } }),
      this.prisma.user.count({ where: { status: 'PENDING' } }),
    ]);
    return { total, green, yellow, red, pending };
  }
}
