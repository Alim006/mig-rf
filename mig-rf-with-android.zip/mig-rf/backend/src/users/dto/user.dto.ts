import { IsString, IsOptional, IsEnum, IsDateString } from 'class-validator';

export class UpdateProfileDto {
  @IsOptional() @IsString() fullName?: string;
  @IsOptional() @IsDateString() birthdate?: string;
  @IsOptional() @IsString() citizenship?: string;
  @IsOptional() @IsString() passportNumber?: string;
  @IsOptional() @IsString() migrationCard?: string;
  @IsOptional() @IsString() address?: string;
  @IsOptional() @IsDateString() entryDate?: string;
  @IsOptional() visitType?: string;
}

export class SetVisitTypeDto {
  @IsString()
  visitType: string;
}
